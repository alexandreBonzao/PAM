import 'dart:math';

void main(){

    //Maps
    Map mapaVazio = {};
    Map mapa = {'key1':1, 'key2':5, 'key3': 'A'};
    mapa['novaChave'] = 'novo elemento';

    print(mapa.keys);
    print(mapa.values);
    print(mapa.length);

    //set
    List lst1 = [1,2,3,3,4];
    List lst2 = [3,4,5,6,6,6];
    Set conj1 = Set.from(lst1);
    Set conj2 = Set.from(lst2);

    print(conj1);
    print(conj2);
    print(conj1.intersection(conj2));
    print(conj1.union(conj2));

    //if else
    int a = 5;
    if(a < 2){
        print('entrou no if');   
    }else{
      print('nao entrou no if');  
    }

    //laco de repetiçao - loop
    for(int i = 0; i<10; i++){
        print(i)
    }

    //funçoes
    int soma(var x,y){
        return x+y;
    }

    var f = soma;

    print(f(2,3));

    print(pi);
}