class Tarefa {
  String descricao;
  int prioridade;
  bool concluida = false;

  Tarefa(this.descricao, this.prioridade);

  @override
  String toString() {
    String status = concluida? 'Concluido' : 'Pendente';
    String prior = prioridade == 1? 'Alta' : prioridade == 2? 'Media' : 'Baixa';
    return 'Descrição $descricao, Prioridade $prior, Status $status';
  }
}

class GerenciadorTarefa{
  List _tarefas = [];

  void adicionarTarefa(Tarefa t){
    _tarefas.add(t);
  }

  void removerTarefa(int id){
    _tarefas.removeAt(id);
  }

  void listarTarefa(){
    print('     Descrição      Prioridade       Status');
    for (int i = 0; i < _tarefas.length; i++){
      print('$i).' +_tarefas[i].toString());
    }
  }
}

void main(){

  GerenciadorTarefa listaDeTarefas = GerenciadorTarefa();

  Tarefa t1 = Tarefa('ir pra academia', 1);
  Tarefa t2 = Tarefa('fazer compras no mercado', 1);
  Tarefa t3 = Tarefa('jogar no bixo', 3);

  List tarefas = [];
  tarefas.add(t1);
  tarefas.add(t2);
  tarefas.add(t3);

  listaDeTarefas.adicionarTarefa(t1);
  listaDeTarefas.adicionarTarefa(t2);
  listaDeTarefas.adicionarTarefa(t3);

  listaDeTarefas.listarTarefa();
  
}