import 'dart:math';

List juntos(List lista1, List lista2){
    List resultado = [];

    for(int i = 0; i < lista1.length; i++){
      resultado.add(lista1[i]);
      resultado.add(lista2[i]);
    }
    return resultado;
}


void main(){
    List lista1 = ["a","b","c","d"];
    List lista2 = [1,2,3,4];

List resultado = juntos(lista1,lista2);
print(resultado);
}
