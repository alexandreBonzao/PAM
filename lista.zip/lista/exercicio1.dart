import 'dart:math';

double calcularMedia (List numero){
    double media = 0;

    for(var e in numero){
        media = media + e;
    }

    return media/numero.length;
}

void main(){
    print(calcularMedia([1,2,3,4,5,6,7,8]));
}
